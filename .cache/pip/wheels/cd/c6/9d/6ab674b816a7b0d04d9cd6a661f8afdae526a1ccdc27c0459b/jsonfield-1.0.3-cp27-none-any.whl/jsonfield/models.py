# Django needs this to see it as a project
